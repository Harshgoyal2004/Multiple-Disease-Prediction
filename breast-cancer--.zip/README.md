# breast-cancer-
Health is an essential aspect of everyone’s life. Breast cancer is found in the body of male or female when the cells in the breast begin to grow out of control. These cells usually form a tumor and can be felt as a lump or could be seen on an x-ray. Cancer can be distinguished as benign, or either can be malignant (cancer).
